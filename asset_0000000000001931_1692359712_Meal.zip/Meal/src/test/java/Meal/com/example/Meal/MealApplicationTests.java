package Meal.com.example.Meal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MealApplicationTests {

	@Test
	void contextLoads() {
	}

}
